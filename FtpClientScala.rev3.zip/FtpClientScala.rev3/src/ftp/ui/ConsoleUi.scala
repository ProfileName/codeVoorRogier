package ftp.ui

import ftp.client.BaseClient
import ftp.client.ClientFactory
import ftp.response.ConsoleReceiver

import java.util._
import java.net._
import java.io._

/**
 * Tests voor de ftpclient.
 */
object ConsoleUi 
{

  def main(args: Array[String]): Unit = 
  {
 
  }
}
