package ftp.client.exceptions

class CDException(val exc: String) extends Exception 
{

}
