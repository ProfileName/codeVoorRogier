package ftp.client.exceptions

import java.lang.Exception

class DisconnectException(val exc: String) extends Exception 
{

}
